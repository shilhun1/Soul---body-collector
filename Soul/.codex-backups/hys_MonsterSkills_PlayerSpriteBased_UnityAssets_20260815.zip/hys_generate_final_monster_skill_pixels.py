from __future__ import annotations

import hashlib
import json
import shutil
from collections import deque
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageDraw


# 실제 플레이어 스프라이트를 캐릭터 베이스로 사용하고 스킬 데이터에 필요한 신규 자세만 보강합니다.
ROOT = Path(__file__).resolve().parents[1]
ASSET_ROOT = ROOT / "Assets/05Anims/hys_Enemy_Anims"
GIF_ROOT = ROOT.parent / "hys_FinalVersion_15_GIFs"
REPORT_ROOT = ROOT / "hys_Reports/MonsterSkillPlayerBased"
CANVAS = (160, 112)
GROUND_Y = 98
FRAME_COUNT = 9
PREVIEW_SCALE = 2
GIF_SCALE = 4


SKILL_DURATIONS_MS = {
    "sword_diagonal_slash": 340,
    "sword_up_diagonal_slash": 340,
    "sword_wave": 530,
    "axe_swing": 340,
    "axe_body_charge": 460,
    "axe_spin_charge": 490,
    "bow_air_arrow_shot": 550,
    "bow_rapid_shot": 620,
    "bow_low_charge_shot": 1100,
    "lance_charge_thrust": 480,
    "lance_thrust_combo": 650,
    "lance_finisher_thrust": 340,
    "shield_charge": 520,
    "shield_slam": 660,
    "shield_diagonal_knockback": 540,
}


SOURCE_ROOTS = {
    "Sword": ROOT / "Assets/05Anims/hys_Player_Anims/Sword/Sprites/hys_RedQueen_RequestedMotions",
    "Axe": ROOT / "Assets/05Anims/hys_Player_Anims/Axe/Sprites/hys_RedKing_PlayerMotions",
    "Bow": ROOT / "Assets/05Anims/hys_Player_Anims/Bow/Sprites/hys_RedBishop_Bow_PlayerMotions",
    "Lance": ROOT / "Assets/05Anims/hys_Player_Anims/Lance/Sprites/hys_RedBishop_PlayerMotions",
    "Shield": ROOT / "Assets/05Anims/hys_Player_Anims/Shield/Sprites",
}


SOURCE_PREFIXES = {
    "Sword": "hys_RedQueen_",
    "Axe": "hys_RedKing_",
    "Bow": "hys_RedBishop_Bow_",
    "Lance": "hys_RedBishop_",
    "Shield": "hys_RedRook_",
}


# 각 원본 시트에서 발 위치가 아니라 몸 중심으로 사용되는 X 좌표입니다.
SOURCE_ANCHOR_X = {
    "Sword": 48,
    "Axe": 31,
    "Bow": 38,
    "Lance": 34,
    "Shield": 20,
}


@dataclass(frozen=True)
class SourcePose:
    motion: str
    index: int
    y: int = 0
    remove_lines: bool = False
    remove_spin_effect: bool = False
    shield_angle: int | None = None
    shield_x: int = 0
    shield_y: int = 0


def poses(motion: str, indices: list[int], **kwargs: object) -> list[SourcePose]:
    return [SourcePose(motion, index, **kwargs) for index in indices]


SKILLS: dict[str, dict[str, list[SourcePose]]] = {
    "Sword": {
        # 1번은 높은 준비에서 오른쪽 아래로 베는 원본 ForwardAttack1 자세를 사용합니다.
        "sword_diagonal_slash": poses("ForwardAttack1", [0, 1, 1, 5, 5, 6, 7, 7, 0]),
        # 2번은 낮은 준비에서 위로 올려 베는 ForwardAttack2의 반대 궤도를 사용합니다.
        "sword_up_diagonal_slash": poses("ForwardAttack2", [0, 1, 1, 4, 5, 5, 6, 7, 0]),
        # 검기는 런타임 투사체가 담당하고 캐릭터는 힘을 모은 뒤 크게 방출하는 자세만 사용합니다.
        "sword_wave": poses("ForwardAttack1", [0, 0, 1, 1, 5, 5, 6, 7, 0]),
    },
    "Axe": {
        "axe_swing": [
            SourcePose("Attack1", index, remove_spin_effect=index == 4)
            for index in [0, 1, 2, 3, 4, 3, 2, 1, 0]
        ],
        # 실제 이동은 DashAction이 담당하므로 모든 프레임은 동일 피벗에 고정합니다.
        "axe_body_charge": poses("Attack1", [0, 1, 2, 3, 2, 1, 0, 1, 0]),
        # 4번 프레임에서는 원호를 제거하고 중앙의 웅크린 회전 본체만 사용합니다.
        "axe_spin_charge": [
            SourcePose("Attack2", index, remove_spin_effect=index == 4)
            for index in [2, 3, 4, 0, 1, 2, 3, 4, 0]
        ],
    },
    "Bow": {
        "bow_air_arrow_shot": [
            SourcePose("JumpStart", 0, y=0),
            SourcePose("JumpStart", 1, y=-5),
            SourcePose("JumpStart", 2, y=-11),
            SourcePose("JumpApex", 0, y=-17),
            SourcePose("Attack1", 2, y=-18),
            SourcePose("Attack1", 3, y=-16),
            SourcePose("Attack1", 4, y=-11),
            SourcePose("JumpFall", 1, y=-5),
            SourcePose("JumpFall", 2, y=0),
        ],
        # 0.11초 간격의 세 발을 당김/발사 자세 세 쌍으로 표시합니다.
        "bow_rapid_shot": poses("Attack1", [0, 2, 3, 2, 3, 2, 3, 4, 5]),
        # 0.75초 충전 구간은 동일한 최대 장력 자세를 의도적으로 유지합니다.
        "bow_low_charge_shot": poses("Attack2", [0, 1, 2, 2, 2, 2, 4, 5, 0]),
    },
    "Lance": {
        "lance_charge_thrust": poses("Attack1", [0, 1, 2, 3, 4, 5, 4, 1, 0]),
        # 홀수 프레임 1/3/5/7이 데이터의 네 번 타격 시점입니다.
        "lance_thrust_combo": [
            SourcePose("Attack1", 0), SourcePose("Attack1", 3),
            SourcePose("Attack2", 0), SourcePose("Attack2", 3),
            SourcePose("Attack1", 0), SourcePose("Attack1", 3),
            SourcePose("Attack2", 0), SourcePose("Attack2", 3),
            SourcePose("Attack1", 5),
        ],
        "lance_finisher_thrust": poses("Attack2", [0, 1, 2, 3, 4, 5, 4, 1, 0]),
    },
    "Shield": {
        "shield_charge": poses("Dash", [0, 1, 2, 3, 4, 5], remove_lines=True)
        + poses("Attack", [3, 4, 5]),
        # 원본 몸체와 방패를 분리한 뒤 방패와 팔의 신규 픽셀을 머리 위로 이동해 내려찍기를 만듭니다.
        "shield_slam": [
            SourcePose("Attack", 0, shield_angle=0),
            SourcePose("Attack", 0, y=-1, shield_angle=15, shield_x=-1, shield_y=-4),
            SourcePose("Attack", 0, y=-2, shield_angle=40, shield_x=-4, shield_y=-11),
            SourcePose("Attack", 0, y=-3, shield_angle=70, shield_x=-7, shield_y=-17),
            SourcePose("Attack", 0, y=1, shield_angle=35, shield_x=-2, shield_y=-9),
            SourcePose("Attack", 0, y=4, shield_angle=-8, shield_x=4, shield_y=2),
            SourcePose("Attack", 0, y=3, shield_angle=-18, shield_x=5, shield_y=4),
            SourcePose("Attack", 0, y=1, shield_angle=-5, shield_x=2, shield_y=1),
            SourcePose("Attack", 0, shield_angle=0),
        ],
        "shield_diagonal_knockback": [
            SourcePose("Attack", 0, shield_angle=0),
            SourcePose("Attack", 1, shield_angle=4, shield_x=-1),
            SourcePose("Attack", 1, shield_angle=15, shield_x=1, shield_y=-2),
            SourcePose("Attack", 2, shield_angle=28, shield_x=3, shield_y=-5),
            SourcePose("Attack", 3, shield_angle=42, shield_x=6, shield_y=-8),
            SourcePose("Attack", 4, shield_angle=55, shield_x=8, shield_y=-10),
            SourcePose("Attack", 5, shield_angle=32, shield_x=5, shield_y=-6),
            SourcePose("Attack", 1, shield_angle=12, shield_x=2, shield_y=-2),
            SourcePose("Attack", 0, shield_angle=0),
        ],
    },
}


def source_path(weapon: str, pose: SourcePose) -> Path:
    return SOURCE_ROOTS[weapon] / f"{SOURCE_PREFIXES[weapon]}{pose.motion}_{pose.index:02d}.png"


def alpha_components(image: Image.Image) -> list[list[tuple[int, int]]]:
    alpha = image.getchannel("A")
    pixels = alpha.load()
    visited: set[tuple[int, int]] = set()
    components: list[list[tuple[int, int]]] = []

    for y in range(image.height):
        for x in range(image.width):
            if pixels[x, y] == 0 or (x, y) in visited:
                continue
            queue: deque[tuple[int, int]] = deque([(x, y)])
            visited.add((x, y))
            component: list[tuple[int, int]] = []
            while queue:
                px, py = queue.popleft()
                component.append((px, py))
                for nx, ny in ((px - 1, py), (px + 1, py), (px, py - 1), (px, py + 1)):
                    if 0 <= nx < image.width and 0 <= ny < image.height and pixels[nx, ny] > 0 and (nx, ny) not in visited:
                        visited.add((nx, ny))
                        queue.append((nx, ny))
            components.append(component)
    return components


def remove_speed_lines(image: Image.Image, weapon: str, anchor_x: int) -> Image.Image:
    """캐릭터 왼쪽에 분리된 가는 속도선만 지우고 본체 픽셀은 보존합니다."""
    result = image.copy()
    pixels = result.load()
    # Red Rook 대시의 속도선은 본체보다 완전히 왼쪽에 있으므로 해당 영역을 먼저 제거합니다.
    if weapon == "Shield":
        for y in range(result.height):
            for x in range(min(18, result.width)):
                pixels[x, y] = (0, 0, 0, 0)
    elif weapon == "Axe":
        # Red King 왼쪽 끝의 선은 완전히 지우고 본체 부근에서는 세로 이웃이 없는 가는 선만 제거합니다.
        original_alpha = image.getchannel("A").load()
        for y in range(result.height):
            for x in range(min(anchor_x, result.width)):
                if x < 11:
                    pixels[x, y] = (0, 0, 0, 0)
                    continue
                vertical_neighbors = 0
                for ny in range(max(0, y - 2), min(result.height, y + 3)):
                    if ny != y and original_alpha[x, ny] > 0:
                        vertical_neighbors += 1
                if vertical_neighbors == 0:
                    pixels[x, y] = (0, 0, 0, 0)
    for component in alpha_components(result):
        xs = [point[0] for point in component]
        ys = [point[1] for point in component]
        width = max(xs) - min(xs) + 1
        height = max(ys) - min(ys) + 1
        if max(xs) < anchor_x and width >= 6 and height <= 3 and len(component) <= 80:
            for x, y in component:
                pixels[x, y] = (0, 0, 0, 0)
    return result


def remove_large_spin_arc(image: Image.Image) -> Image.Image:
    """Axe 회전 원본에서 몸체보다 큰 주황/적색 원호만 제거합니다."""
    result = image.copy()
    rgba = result.load()
    neutral: set[tuple[int, int]] = set()
    for y in range(result.height):
        for x in range(result.width):
            r, g, b, a = rgba[x, y]
            if a > 0 and max(r, g, b) - min(r, g, b) < 58:
                neutral.add((x, y))
    visited: set[tuple[int, int]] = set()
    neutral_components: list[list[tuple[int, int]]] = []
    for start in neutral:
        if start in visited:
            continue
        queue: deque[tuple[int, int]] = deque([start])
        visited.add(start)
        component: list[tuple[int, int]] = []
        while queue:
            x, y = queue.popleft()
            component.append((x, y))
            for point in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                if point in neutral and point not in visited:
                    visited.add(point)
                    queue.append(point)
        neutral_components.append(component)

    if not neutral_components:
        return result

    def body_score(component: list[tuple[int, int]]) -> float:
        xs = [point[0] for point in component]
        ys = [point[1] for point in component]
        width = max(xs) - min(xs) + 1
        height = max(ys) - min(ys) + 1
        density = len(component) / float(width * height)
        center_x = (min(xs) + max(xs)) / 2.0
        center_y = (min(ys) + max(ys)) / 2.0
        distance = abs(center_x - 32) + abs(center_y - 34)
        return len(component) * density / (1.0 + distance / 24.0)

    body_core = max(neutral_components, key=body_score)
    keep: set[tuple[int, int]] = set()
    for x, y in body_core:
        for dy in range(-5, 6):
            for dx in range(-5, 6):
                nx, ny = x + dx, y + dy
                if 0 <= nx < result.width and 0 <= ny < result.height:
                    keep.add((nx, ny))
    for y in range(result.height):
        for x in range(result.width):
            if (x, y) not in keep:
                rgba[x, y] = (0, 0, 0, 0)
                continue
            r, g, b, a = rgba[x, y]
            # 웅크린 본체 아래에 붙은 마지막 붉은 원호 조각을 제거합니다.
            if y > 43 and a > 0 and r > 45 and r > g * 1.22 and r > b * 1.08:
                rgba[x, y] = (0, 0, 0, 0)
    return result


def paste_player_base(canvas: Image.Image, weapon: str, source: Image.Image, y_offset: int) -> tuple[int, int]:
    box = source.getchannel("A").getbbox()
    if box is None:
        raise ValueError(f"투명한 원본 스프라이트입니다: {weapon}")
    destination_x = 50 - SOURCE_ANCHOR_X[weapon]
    destination_y = GROUND_Y - (box[3] - 1) + y_offset
    canvas.alpha_composite(source, (destination_x, destination_y))
    return destination_x, destination_y


def redraw_shield_pose(canvas: Image.Image, source: Image.Image, destination: tuple[int, int], pose: SourcePose) -> None:
    """Red Rook 본체는 유지하고 방패와 연결 팔만 신규 각도로 다시 배치합니다."""
    dx, dy = destination
    shield_box = (24, 8, 49, 50)
    shield = source.crop(shield_box)
    clear = Image.new("RGBA", (shield_box[2] - shield_box[0], shield_box[3] - shield_box[1]), (0, 0, 0, 0))
    canvas.paste(clear, (dx + shield_box[0], dy + shield_box[1]))

    rotated = shield.rotate(pose.shield_angle or 0, resample=Image.Resampling.NEAREST, expand=True)
    target_x = dx + 24 + pose.shield_x - (rotated.width - shield.width) // 2
    target_y = dy + 8 + pose.shield_y - (rotated.height - shield.height) // 2

    draw = ImageDraw.Draw(canvas)
    shoulder = (dx + 21, dy + 28)
    shield_center = (target_x + rotated.width // 2, target_y + rotated.height // 2)
    draw.line((shoulder, shield_center), fill=(26, 27, 29, 255), width=4)
    draw.line((shoulder, shield_center), fill=(126, 126, 126, 255), width=2)
    canvas.alpha_composite(rotated, (target_x, target_y))


def render_frame(weapon: str, pose: SourcePose) -> tuple[Image.Image, str, list[str]]:
    path = source_path(weapon, pose)
    if not path.exists():
        raise FileNotFoundError(path)
    source = Image.open(path).convert("RGBA")
    edits: list[str] = []

    if pose.remove_lines:
        source = remove_speed_lines(source, weapon, SOURCE_ANCHOR_X[weapon])
        edits.append("remove_baked_speed_lines")
    if pose.remove_spin_effect:
        source = remove_large_spin_arc(source)
        edits.append("remove_baked_spin_arc")

    canvas = Image.new("RGBA", CANVAS, (0, 0, 0, 0))
    destination = paste_player_base(canvas, weapon, source, pose.y)
    if pose.shield_angle is not None:
        # 먼저 붙인 원본 방패를 지운 뒤 신규 각도로 다시 그립니다.
        redraw_shield_pose(canvas, source, destination, pose)
        edits.append("redraw_shield_and_arm_pixels")

    return canvas, str(path.relative_to(ROOT)).replace("\\", "/"), edits


def build_skill(weapon: str, skill: str, sequence: list[SourcePose]) -> dict[str, object]:
    if len(sequence) != FRAME_COUNT:
        raise ValueError(f"{skill}: {FRAME_COUNT}프레임이 아닙니다")
    frame_dir = ASSET_ROOT / weapon / "Sprites/hys_FinalSkills" / skill
    frame_dir.mkdir(parents=True, exist_ok=True)
    frames: list[Image.Image] = []
    frame_sources: list[dict[str, object]] = []

    for index, pose in enumerate(sequence):
        frame, source, edits = render_frame(weapon, pose)
        output = frame_dir / f"hys_Enemy_{weapon}_{skill}_{index:02d}.png"
        frame.save(output)
        frames.append(frame)
        frame_sources.append({"frame": index, "source": source, "edits": edits})

    gif_frames = [frame.resize((CANVAS[0] * GIF_SCALE, CANVAS[1] * GIF_SCALE), Image.Resampling.NEAREST) for frame in frames]
    frame_ms = max(20, round(SKILL_DURATIONS_MS[skill] / FRAME_COUNT / 10) * 10)
    GIF_ROOT.mkdir(parents=True, exist_ok=True)
    gif_path = GIF_ROOT / f"hys_Final_Enemy_{weapon}_{skill}.gif"
    gif_frames[0].save(
        gif_path,
        save_all=True,
        append_images=gif_frames[1:],
        duration=frame_ms,
        loop=0,
        disposal=2,
        optimize=False,
    )
    return {
        "weapon": weapon,
        "skill": skill,
        "duration_ms": SKILL_DURATIONS_MS[skill],
        "gif_frame_ms": frame_ms,
        "frame_sources": frame_sources,
        "hashes": [hashlib.sha256(frame.tobytes()).hexdigest() for frame in frames],
        "gif": str(gif_path),
    }


def build_contact_sheet(results: list[dict[str, object]]) -> None:
    row_height = CANVAS[1] * PREVIEW_SCALE
    label_width = 310
    sheet = Image.new("RGB", (label_width + CANVAS[0] * PREVIEW_SCALE * FRAME_COUNT, row_height * len(results)), "#1c2029")
    draw = ImageDraw.Draw(sheet)
    for row, result in enumerate(results):
        weapon = str(result["weapon"])
        skill = str(result["skill"])
        draw.text((8, row * row_height + 8), f"{weapon} / {skill}", fill="white")
        draw.text((8, row * row_height + 28), "PLAYER SPRITE BASED", fill="#f2c45b")
        frame_dir = ASSET_ROOT / weapon / "Sprites/hys_FinalSkills" / skill
        for index in range(FRAME_COUNT):
            frame = Image.open(frame_dir / f"hys_Enemy_{weapon}_{skill}_{index:02d}.png").convert("RGBA")
            layer = Image.new("RGBA", CANVAS, "#1c2029")
            layer.alpha_composite(frame)
            layer = layer.resize((CANVAS[0] * PREVIEW_SCALE, row_height), Image.Resampling.NEAREST)
            sheet.paste(layer.convert("RGB"), (label_width + index * CANVAS[0] * PREVIEW_SCALE, row * row_height))
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    sheet.save(REPORT_ROOT / "hys_PlayerBased_15_AllFrames.png")


def build_animated_preview(results: list[dict[str, object]]) -> None:
    columns = 3
    rows = 5
    cell_width = CANVAS[0] * PREVIEW_SCALE
    cell_height = CANVAS[1] * PREVIEW_SCALE + 24
    preview_frames: list[Image.Image] = []
    for frame_index in range(FRAME_COUNT):
        preview = Image.new("RGB", (cell_width * columns, cell_height * rows), "#1c2029")
        draw = ImageDraw.Draw(preview)
        for item_index, result in enumerate(results):
            weapon = str(result["weapon"])
            skill = str(result["skill"])
            source = ASSET_ROOT / weapon / "Sprites/hys_FinalSkills" / skill / f"hys_Enemy_{weapon}_{skill}_{frame_index:02d}.png"
            sprite = Image.open(source).convert("RGBA").resize((CANVAS[0] * PREVIEW_SCALE, CANVAS[1] * PREVIEW_SCALE), Image.Resampling.NEAREST)
            cell_x = item_index % columns * cell_width
            cell_y = item_index // columns * cell_height
            draw.text((cell_x + 5, cell_y + 5), f"{weapon} / {skill}", fill="white")
            layer = Image.new("RGBA", sprite.size, "#1c2029")
            layer.alpha_composite(sprite)
            preview.paste(layer.convert("RGB"), (cell_x, cell_y + 24))
        preview_frames.append(preview)
    preview_frames[0].save(
        REPORT_ROOT / "hys_PlayerBased_15_AnimatedPreview.gif",
        save_all=True,
        append_images=preview_frames[1:],
        duration=90,
        loop=0,
        optimize=False,
    )


def main() -> None:
    if GIF_ROOT.exists():
        shutil.rmtree(GIF_ROOT)
    results: list[dict[str, object]] = []
    for weapon, skill_map in SKILLS.items():
        for skill, sequence in skill_map.items():
            results.append(build_skill(weapon, skill, sequence))
    build_contact_sheet(results)
    build_animated_preview(results)
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    report = [{key: value for key, value in result.items() if key != "hashes"} for result in results]
    (REPORT_ROOT / "hys_PlayerBased_15_SourceAudit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Player-based monster skills exported: {GIF_ROOT}")


if __name__ == "__main__":
    main()
