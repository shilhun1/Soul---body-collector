from __future__ import annotations

import hashlib
import json
import math
import shutil
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageDraw


# 15개 몬스터 스킬을 기존 플레이어 프레임 재활용 없이 저해상도 픽셀로 직접 그립니다.
ROOT = Path(__file__).resolve().parents[1]
ASSET_ROOT = ROOT / "Assets/05Anims/hys_Enemy_Anims"
GIF_ROOT = ROOT.parent / "hys_FinalVersion_15_GIFs"
REPORT_ROOT = ROOT / "hys_Reports/MonsterSkillFinal"
CANVAS = (160, 112)
SCALE = 4
FRAME_COUNT = 9
GROUND_Y = 98

# 실제 스킬 데이터의 준비, 판정, 회복 시간을 합친 애니메이션 길이입니다.
# 돌진 거리는 런타임이 이동시키므로 스프라이트 프레임에는 수평 이동을 굽지 않습니다.
SKILL_DURATIONS_MS = {
    "sword_diagonal_slash": 340,
    "sword_up_diagonal_slash": 340,
    "sword_wave": 530,
    "axe_swing": 340,
    "axe_body_charge": 460,
    "axe_spin_charge": 490,
    "bow_air_arrow_shot": 550,
    "bow_rapid_shot": 620,
    "bow_low_charge_shot": 1100,
    "lance_charge_thrust": 480,
    "lance_thrust_combo": 650,
    "lance_finisher_thrust": 340,
    "shield_charge": 520,
    "shield_slam": 660,
    "shield_diagonal_knockback": 540,
}


PALETTES = {
    # 원본 몬스터 PNG에서 확인한 대표색을 사용해 직업별 팔레트를 고정합니다.
    "Sword": {"outline": "#1b2732", "dark": "#48433d", "armor": "#bdb7ab", "light": "#d9d5c8", "red": "#400b07", "bright": "#560d05", "gold": "#7f6a4f", "effect": "#d7b15c"},
    "Axe": {"outline": "#090a0b", "dark": "#33343c", "armor": "#898887", "light": "#b8b5b1", "red": "#3b312d", "bright": "#71351f", "gold": "#949faa", "effect": "#ef6b35"},
    "Bow": {"outline": "#0f0f0d", "dark": "#1f1f1f", "armor": "#4b4943", "light": "#a6a4a2", "red": "#382822", "bright": "#725142", "gold": "#8c6947", "effect": "#d9ad55"},
    "Lance": {"outline": "#130708", "dark": "#3a1010", "armor": "#696158", "light": "#d7cab8", "red": "#3a1010", "bright": "#6d1515", "gold": "#a39689", "effect": "#d9b36a"},
    "Shield": {"outline": "#20262a", "dark": "#424c57", "armor": "#767777", "light": "#b5b3b2", "red": "#37424d", "bright": "#54606d", "gold": "#8a7d61", "effect": "#e4e4e4"},
}

# 직업별 원본 실루엣 차이를 고정합니다. 같은 직업 안에서는 이 값이 절대 변하지 않습니다.
BODY_SPECS = {
    "Sword": {"torso_w": 19, "torso_h": 18, "head_w": 14, "head_h": 12, "leg_w": 5, "arm_w": 5, "shoulder": 7, "cape": 12, "helm": "crest"},
    "Axe": {"torso_w": 27, "torso_h": 19, "head_w": 18, "head_h": 13, "leg_w": 7, "arm_w": 7, "shoulder": 10, "cape": 11, "helm": "horn"},
    "Bow": {"torso_w": 18, "torso_h": 19, "head_w": 15, "head_h": 13, "leg_w": 5, "arm_w": 5, "shoulder": 9, "cape": 15, "helm": "hood"},
    "Lance": {"torso_w": 17, "torso_h": 19, "head_w": 14, "head_h": 13, "leg_w": 5, "arm_w": 5, "shoulder": 7, "cape": 17, "helm": "plume"},
    "Shield": {"torso_w": 23, "torso_h": 18, "head_w": 17, "head_h": 12, "leg_w": 6, "arm_w": 6, "shoulder": 9, "cape": 9, "helm": "round"},
}


SKILLS = {
    "Sword": ["sword_diagonal_slash", "sword_up_diagonal_slash", "sword_wave"],
    "Axe": ["axe_swing", "axe_body_charge", "axe_spin_charge"],
    "Bow": ["bow_air_arrow_shot", "bow_rapid_shot", "bow_low_charge_shot"],
    "Lance": ["lance_charge_thrust", "lance_thrust_combo", "lance_finisher_thrust"],
    "Shield": ["shield_charge", "shield_slam", "shield_diagonal_knockback"],
}


@dataclass(frozen=True)
class Pose:
    x: int = 50
    y: int = 0
    lean: int = 0
    crouch: int = 0
    front_arm: int = 0
    back_arm: int = 0
    front_leg: int = 2
    back_leg: int = -2
    weapon_angle: int = 0
    cape: int = 0
    airborne: bool = False
    shield_angle: int = 0


def pt(origin: tuple[int, int], length: float, angle: float) -> tuple[int, int]:
    radians = math.radians(angle)
    return round(origin[0] + math.cos(radians) * length), round(origin[1] + math.sin(radians) * length)


def thick_line(draw: ImageDraw.ImageDraw, points: list[tuple[int, int]], fill: str, outline: str, width: int) -> None:
    draw.line(points, fill=outline, width=width + 3, joint="curve")
    draw.line(points, fill=fill, width=width, joint="curve")


def polygon(draw: ImageDraw.ImageDraw, points: list[tuple[int, int]], fill: str, outline: str, width: int = 1) -> None:
    draw.polygon(points, fill=fill)
    draw.line(points + [points[0]], fill=outline, width=width, joint="curve")


def draw_arc_pixels(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], start: int, end: int, color: str, width: int = 3) -> None:
    draw.arc(box, start=start, end=end, fill=color, width=width)


def draw_effects(draw: ImageDraw.ImageDraw, weapon: str, skill: str, frame: int, pose: Pose, palette: dict[str, str]) -> None:
    phase = frame / (FRAME_COUNT - 1)
    x = pose.x
    y = GROUND_Y + pose.y
    if 2 <= frame <= 6:
        if skill == "sword_diagonal_slash":
            draw_arc_pixels(draw, (x - 8, y - 70, x + 58, y - 5), 285, 62, palette["effect"], 3)
        elif skill == "sword_up_diagonal_slash":
            draw_arc_pixels(draw, (x - 8, y - 62, x + 54, y + 2), 205, 322, palette["effect"], 3)
        elif skill == "sword_wave" and frame >= 4:
            wx = x + 24 + (frame - 4) * 15
            draw_arc_pixels(draw, (wx - 6, y - 55, wx + 24, y - 9), 250, 110, palette["effect"], 4)
            draw_arc_pixels(draw, (wx, y - 50, wx + 30, y - 14), 250, 110, palette["bright"], 2)
        elif skill == "axe_swing":
            draw_arc_pixels(draw, (x - 18, y - 74, x + 56, y - 2), 270, 78, palette["gold"], 5)
        elif skill == "axe_body_charge":
            for n in range(3):
                dx = x - 20 - n * 8 - frame * 2
                draw.line((dx, y - 18 - n * 5, dx + 10, y - 18 - n * 5), fill=palette["bright"], width=2)
            draw.ellipse((x - 18, y - 3, x - 8, y + 1), fill=palette["dark"])
        elif skill == "axe_spin_charge":
            draw_arc_pixels(draw, (x - 38, y - 72, x + 52, y + 8), frame * 42, frame * 42 + 245, palette["effect"], 5)
        elif skill == "bow_air_arrow_shot" and frame >= 4:
            ax = x + 26 + (frame - 4) * 13
            ay = y - 44 + (frame - 4) * 8
            draw.line((ax, ay, ax + 15, ay + 7), fill=palette["light"], width=2)
            polygon(draw, [(ax + 15, ay + 7), (ax + 10, ay + 3), (ax + 11, ay + 9)], palette["effect"], palette["outline"])
        elif skill == "bow_rapid_shot" and frame >= 3:
            for n in range(min(3, frame - 2)):
                ax = x + 32 + n * 17 + (frame - 3) * 5
                ay = y - 39 + n * 3
                draw.line((ax, ay, ax + 15, ay), fill=palette["light"], width=2)
        elif skill == "bow_low_charge_shot":
            radius = 2 + min(frame, 5)
            draw.ellipse((x + 26 - radius, y - 30 - radius, x + 26 + radius, y - 30 + radius), outline=palette["effect"], width=2)
            if frame >= 5:
                draw.line((x + 38, y - 30, x + 110, y - 30), fill=palette["effect"], width=3)
        elif skill == "lance_charge_thrust":
            for n in range(3):
                draw.line((x - 28 - n * 8, y - 17 - n * 4, x - 8 - n * 8, y - 17 - n * 4), fill=palette["bright"], width=2)
        elif skill == "lance_thrust_combo":
            impact_y = y - 36 + (frame % 2) * 9
            draw.line((x + 60, impact_y, x + 76, impact_y), fill=palette["effect"], width=3)
        elif skill == "lance_finisher_thrust":
            draw.polygon([(x + 54, y - 42), (x + 78, y - 32), (x + 54, y - 22)], fill=palette["bright"])
            draw.line((x + 54, y - 32, x + 82, y - 32), fill=palette["effect"], width=3)
        elif skill == "shield_charge":
            for n in range(4):
                draw.line((x - 24 - n * 7, y - 15 - n * 5, x - 8 - n * 7, y - 15 - n * 5), fill=palette["bright"], width=2)
        elif skill == "shield_slam" and frame >= 4:
            draw.line((x - 22, y, x + 30, y), fill=palette["effect"], width=3)
            for n in range(5):
                sx = x - 18 + n * 12
                draw.line((sx, y, sx + (n - 2) * 3, y - 10 - abs(n - 2) * 2), fill=palette["gold"], width=2)
        elif skill == "shield_diagonal_knockback":
            draw_arc_pixels(draw, (x - 6, y - 66, x + 55, y - 4), 205, 320, palette["effect"], 5)


def draw_sword(draw: ImageDraw.ImageDraw, hand: tuple[int, int], angle: int, p: dict[str, str]) -> None:
    # Sword 몬스터 원본 무기 규격: 붉은 손잡이 7px, 은색 직선 칼날 29px, 금색 가드 7px를 전 프레임에 고정합니다.
    pommel = pt(hand, 7, angle + 180)
    guard_center = pt(hand, 2, angle)
    blade_base = pt(hand, 5, angle)
    # 캔버스 가장자리에서 칼끝이 잘리지 않도록 원본 비율 안에서 칼날을 27px로 고정합니다.
    tip = pt(blade_base, 27, angle)
    perp = angle + 90
    g1, g2 = pt(guard_center, 3, perp), pt(guard_center, 3, perp + 180)
    thick_line(draw, [pommel, hand], p["red"], p["outline"], 3)
    thick_line(draw, [g1, g2], p["armor"], p["outline"], 2)
    thick_line(draw, [blade_base, tip], p["light"], p["outline"], 2)
    draw.point(tip, fill=p["light"])


def draw_axe(draw: ImageDraw.ImageDraw, hand: tuple[int, int], angle: int, p: dict[str, str]) -> None:
    base = pt(hand, 11, angle + 180)
    # 큰 양날 도끼의 인상은 유지하면서 회전 프레임의 상하 잘림을 막습니다.
    head = pt(hand, 24, angle)
    thick_line(draw, [base, head], p["red"], p["outline"], 3)
    side = angle + 90
    a = pt(head, 8, side)
    b = pt(head, 8, side + 180)
    polygon(draw, [head, pt(a, 7, angle + 180), pt(a, 5, side), pt(a, 5, angle), pt(head, 3, angle)], p["light"], p["outline"], 2)
    polygon(draw, [head, pt(b, 7, angle + 180), pt(b, 5, side + 180), pt(b, 5, angle), pt(head, 3, angle)], p["armor"], p["outline"], 2)
    draw.line((pt(a, 6, angle + 180), pt(a, 4, angle)), fill=p["gold"], width=2)
    draw.line((pt(b, 6, angle + 180), pt(b, 4, angle)), fill=p["gold"], width=2)
    draw.ellipse((head[0] - 3, head[1] - 3, head[0] + 3, head[1] + 3), fill=p["dark"], outline=p["outline"])


def draw_bow(draw: ImageDraw.ImageDraw, hand: tuple[int, int], angle: int, p: dict[str, str], drawn: int) -> None:
    axis = angle + 90
    top = pt(hand, 18, axis)
    bottom = pt(hand, 18, axis + 180)
    forward = pt(hand, 7, angle)
    back = pt(hand, 4 + drawn, angle + 180)
    draw.line([top, forward, bottom], fill=p["outline"], width=4, joint="curve")
    draw.line([top, forward, bottom], fill=p["gold"], width=2, joint="curve")
    draw.line([top, back, bottom], fill=p["light"], width=1)
    draw.line((back, pt(back, 30, angle)), fill=p["gold"], width=2)


def draw_lance(draw: ImageDraw.ImageDraw, hand: tuple[int, int], angle: int, p: dict[str, str]) -> None:
    base = pt(hand, 17, angle + 180)
    shaft_end = pt(hand, 42, angle)
    tip = pt(shaft_end, 9, angle)
    thick_line(draw, [base, shaft_end], p["red"], p["outline"], 2)
    side = angle + 90
    polygon(draw, [shaft_end, pt(shaft_end, 4, side), tip, pt(shaft_end, 4, side + 180)], p["light"], p["outline"])
    draw.rectangle((base[0] - 2, base[1] - 2, base[0] + 2, base[1] + 2), fill=p["gold"], outline=p["outline"])
    tassel = pt(shaft_end, 5, angle + 180)
    polygon(draw, [pt(tassel, 2, angle + 90), pt(tassel, 7, angle + 145), pt(tassel, 2, angle - 90)], p["bright"], p["outline"])


def draw_shield(draw: ImageDraw.ImageDraw, hand: tuple[int, int], angle: int, p: dict[str, str]) -> None:
    center = pt(hand, 5, angle)
    layer = Image.new("RGBA", (42, 52), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    polygon(ld, [(5, 3), (36, 3), (38, 32), (21, 48), (4, 32)], p["light"], p["outline"], 2)
    polygon(ld, [(8, 7), (33, 7), (34, 30), (21, 43), (8, 30)], p["bright"], p["gold"], 2)
    polygon(ld, [(12, 10), (29, 10), (30, 27), (21, 37), (12, 27)], p["red"], p["dark"], 1)
    ld.line((21, 9, 21, 37), fill=p["gold"], width=2)
    ld.line((12, 18, 30, 18), fill=p["armor"], width=2)
    rotated = layer.rotate(-angle, resample=Image.Resampling.NEAREST, expand=True)
    draw._image.alpha_composite(rotated, (center[0] - rotated.width // 2, center[1] - rotated.height // 2))


def draw_job_armor_details(
    draw: ImageDraw.ImageDraw,
    weapon: str,
    shoulder: tuple[int, int],
    hip: tuple[int, int],
    head: tuple[int, int],
    p: dict[str, str],
) -> None:
    """원본 5종 몬스터의 고유 갑옷 표식을 새 픽셀로 덧그립니다."""
    sx, sy = shoulder
    hx, hy = hip
    nx, ny = head
    if weapon == "Sword":
        polygon(draw, [(sx - 10, sy - 1), (sx - 4, sy - 5), (sx - 1, sy + 2), (sx - 8, sy + 5)], p["light"], p["outline"], 2)
        polygon(draw, [(sx + 3, sy - 4), (sx + 10, sy), (sx + 8, sy + 5), (sx + 1, sy + 2)], p["armor"], p["outline"], 2)
        draw.line((sx - 5, sy + 5, hx + 4, hy - 1), fill=p["dark"], width=3)
        draw.rectangle((hx - 8, hy + 3, hx - 2, hy + 11), fill=p["red"], outline=p["outline"])
        draw.rectangle((hx + 2, hy + 3, hx + 7, hy + 10), fill=p["bright"], outline=p["outline"])
    elif weapon == "Axe":
        polygon(draw, [(sx - 16, sy + 1), (sx - 11, sy - 8), (sx - 3, sy - 5), (sx - 5, sy + 6)], p["dark"], p["outline"], 2)
        polygon(draw, [(sx + 4, sy - 6), (sx + 14, sy - 8), (sx + 17, sy + 2), (sx + 6, sy + 6)], p["armor"], p["outline"], 2)
        polygon(draw, [(sx - 12, sy - 8), (sx - 10, sy - 14), (sx - 6, sy - 7)], p["light"], p["outline"])
        polygon(draw, [(sx + 11, sy - 8), (sx + 15, sy - 14), (sx + 15, sy - 6)], p["gold"], p["outline"])
        draw.rectangle((sx - 8, sy + 4, hx + 9, hy - 1), fill=p["dark"], outline=p["outline"])
        draw.line((sx - 5, sy + 6, hx + 6, hy - 3), fill=p["gold"], width=3)
        draw.ellipse((hx - 4, hy - 3, hx + 4, hy + 5), fill=p["armor"], outline=p["outline"])
    elif weapon == "Bow":
        for offset in (-11, -7, 7, 11):
            direction = -1 if offset < 0 else 1
            polygon(draw, [(sx + offset, sy), (sx + offset + direction * 8, sy - 5), (sx + offset + direction * 4, sy + 5)], p["dark"], p["outline"])
        draw.rectangle((sx - 7, sy + 3, hx + 7, hy + 2), fill=p["armor"], outline=p["outline"])
        draw.line((sx - 5, sy + 5, hx + 5, hy), fill=p["light"], width=2)
        draw.rectangle((hx - 7, hy + 2, hx - 2, hy + 10), fill=p["dark"], outline=p["outline"])
        draw.rectangle((hx + 2, hy + 2, hx + 7, hy + 9), fill=p["red"], outline=p["outline"])
    elif weapon == "Lance":
        polygon(draw, [(sx - 9, sy), (sx - 4, sy - 5), (sx, sy + 3), (sx - 7, sy + 6)], p["gold"], p["outline"], 2)
        polygon(draw, [(sx + 2, sy - 4), (sx + 9, sy), (sx + 7, sy + 6), (sx, sy + 3)], p["armor"], p["outline"], 2)
        draw.rectangle((sx - 6, sy + 3, hx + 7, hy + 3), fill=p["dark"], outline=p["outline"])
        polygon(draw, [(hx - 7, hy + 1), (hx - 2, hy + 1), (hx - 4, hy + 14), (hx - 10, hy + 10)], p["red"], p["outline"])
        polygon(draw, [(hx + 1, hy + 1), (hx + 7, hy + 1), (hx + 10, hy + 11), (hx + 4, hy + 14)], p["bright"], p["outline"])
    elif weapon == "Shield":
        polygon(draw, [(sx - 14, sy + 1), (sx - 10, sy - 7), (sx - 2, sy - 5), (sx - 5, sy + 6)], p["light"], p["outline"], 2)
        polygon(draw, [(sx + 3, sy - 6), (sx + 12, sy - 7), (sx + 15, sy + 2), (sx + 5, sy + 6)], p["armor"], p["outline"], 2)
        draw.rectangle((sx - 8, sy + 4, hx + 9, hy + 2), fill=p["bright"], outline=p["outline"])
        draw.line((sx, sy + 5, sx, hy + 1), fill=p["gold"], width=3)
        polygon(draw, [(hx - 8, hy + 1), (hx + 8, hy + 1), (hx + 6, hy + 11), (hx - 6, hy + 11)], p["dark"], p["outline"], 2)

    # 얼굴 방향은 모든 직업에서 오른쪽으로 고정합니다.
    draw.rectangle((nx + 1, ny - 2, nx + 7, ny + 3), fill=p["outline"])
    draw.point((nx + 5, ny), fill=p["effect"])


def draw_character(image: Image.Image, weapon: str, pose: Pose, frame: int, skill: str) -> None:
    p = PALETTES[weapon]
    spec = BODY_SPECS[weapon]
    draw = ImageDraw.Draw(image)
    # 검기, 화살, 속도선, 충돌 섬광은 런타임 이펙트가 담당하므로 캐릭터 도트에는 그리지 않습니다.
    ground = GROUND_Y + pose.y
    # 원본 64px 캐릭터 높이에 맞춰 발바닥부터 골반까지의 기준 높이를 고정합니다.
    hip = (pose.x + pose.lean // 3, ground - 23 - pose.crouch)
    shoulder = (hip[0] + pose.lean // 4, hip[1] - int(spec["torso_h"]) + 3 + pose.crouch // 2)
    head = (shoulder[0] + pose.lean // 5, shoulder[1] - 8)

    # 망토는 몸 뒤에서만 움직이며 몸통/갑옷 비율에는 영향을 주지 않습니다.
    cape_length = int(spec["cape"])
    cape_tip = (hip[0] - cape_length - pose.cape, ground - 5 + min(4, abs(pose.cape) // 2))
    polygon(draw, [(shoulder[0] - int(spec["shoulder"]), shoulder[1]), (hip[0] - 5, hip[1] + 7), cape_tip, (shoulder[0] - 8 - pose.cape // 2, shoulder[1] + 5)], p["red"], p["outline"], 2)

    def leg(side: int, stride: int) -> None:
        h = (hip[0] + side * 3, hip[1] + 4)
        knee = (h[0] + stride // 2, ground - 11 - max(0, pose.crouch // 2))
        foot = (hip[0] + stride, ground)
        thick_line(draw, [h, knee, foot], p["armor" if side > 0 else "dark"], p["outline"], int(spec["leg_w"]))
        draw.line((foot[0] - 3, foot[1], foot[0] + 5, foot[1]), fill=p["outline"], width=3)

    leg(-1, pose.back_leg)
    leg(1, pose.front_leg)

    # 직업별 체형표의 몸통과 머리 치수를 사용하며 애니메이션 프레임에서는 크기를 바꾸지 않습니다.
    half_torso = int(spec["torso_w"]) // 2
    polygon(draw, [(shoulder[0] - half_torso, shoulder[1]), (shoulder[0] + half_torso, shoulder[1]), (hip[0] + half_torso, hip[1] + 5), (hip[0] - half_torso, hip[1] + 5)], p["armor"], p["outline"], 2)
    draw.line((shoulder[0] - 4, shoulder[1] + 5, hip[0] + 4, hip[1] + 2), fill=p["light"], width=2)
    draw.rectangle((hip[0] - 8, hip[1], hip[0] + 8, hip[1] + 4), fill=p["dark"], outline=p["outline"])
    draw.rectangle((hip[0] - 1, hip[1], hip[0] + 2, hip[1] + 4), fill=p["gold"])

    shoulder_span = int(spec["shoulder"])
    back_shoulder = (shoulder[0] - shoulder_span, shoulder[1] + 3)
    front_shoulder = (shoulder[0] + shoulder_span, shoulder[1] + 3)
    back_elbow = pt(back_shoulder, 9, pose.back_arm)
    front_elbow = pt(front_shoulder, 9, pose.front_arm)
    back_hand = pt(back_elbow, 8, pose.back_arm + 5)
    front_hand = pt(front_elbow, 8, pose.front_arm - 4)
    thick_line(draw, [back_shoulder, back_elbow, back_hand], p["dark"], p["outline"], int(spec["arm_w"]))
    thick_line(draw, [front_shoulder, front_elbow, front_hand], p["armor"], p["outline"], int(spec["arm_w"]))

    # 원본의 뾰족한 은색 투구와 붉은 얼굴 가리개를 고정 디자인으로 유지합니다.
    half_head = int(spec["head_w"]) // 2
    half_head_h = int(spec["head_h"]) // 2
    draw.ellipse((head[0] - half_head, head[1] - half_head_h, head[0] + half_head, head[1] + half_head_h), fill=p["armor"], outline=p["outline"], width=2)
    helm = str(spec["helm"])
    if helm == "horn":
        polygon(draw, [(head[0] - 6, head[1] - 5), (head[0] - 10, head[1] - 10), (head[0] - 3, head[1] - 7)], p["light"], p["outline"])
        polygon(draw, [(head[0] + 4, head[1] - 6), (head[0] + 9, head[1] - 11), (head[0] + 8, head[1] - 4)], p["gold"], p["outline"])
    elif helm == "hood":
        draw.arc((head[0] - half_head - 3, head[1] - half_head_h - 3, head[0] + half_head + 3, head[1] + half_head_h + 2), 175, 370, fill=p["light"], width=3)
        draw.arc((head[0] - half_head, head[1] - half_head_h, head[0] + half_head, head[1] + half_head_h + 4), 200, 345, fill=p["dark"], width=3)
    elif helm == "plume":
        polygon(draw, [(head[0] - 5, head[1] - 5), (head[0], head[1] - 12), (head[0] + 6, head[1] - 4)], p["gold"], p["outline"], 2)
        polygon(draw, [(head[0] - 1, head[1] - 11), (head[0] - 6, head[1] - 18), (head[0] + 2, head[1] - 14)], p["red"], p["outline"], 2)
    elif helm == "bishop":
        polygon(draw, [(head[0] - 4, head[1] - 5), (head[0] + 1, head[1] - 17), (head[0] + 5, head[1] - 4)], p["light"], p["outline"], 2)
    elif helm == "round":
        draw.arc((head[0] - half_head - 1, head[1] - half_head_h - 2, head[0] + half_head + 1, head[1] + half_head_h), 180, 355, fill=p["light"], width=2)
    else:
        polygon(draw, [(head[0] - 4, head[1] - 5), (head[0] + 1, head[1] - 11), (head[0] + 5, head[1] - 4)], p["light"], p["outline"], 2)
    draw.rectangle((head[0] + 1, head[1] - 1, head[0] + 7, head[1] + 3), fill=p["red"], outline=p["outline"])
    draw.point((head[0] + 5, head[1]), fill=p["effect"])

    draw_job_armor_details(draw, weapon, shoulder, hip, head, p)

    if weapon == "Sword":
        draw_sword(draw, front_hand, pose.weapon_angle, p)
    elif weapon == "Axe":
        draw_axe(draw, front_hand, pose.weapon_angle, p)
    elif weapon == "Bow":
        draw_bow(draw, front_hand, pose.weapon_angle, p, max(0, min(9, abs(pose.back_arm - pose.front_arm) // 7)))
    elif weapon == "Lance":
        draw_lance(draw, front_hand, pose.weapon_angle, p)
    elif weapon == "Shield":
        draw_shield(draw, front_hand, pose.shield_angle, p)


def pose_for(skill: str, frame: int) -> Pose:
    t = frame / (FRAME_COUNT - 1)
    recover = frame >= 7
    if skill == "sword_diagonal_slash":
        angles = [-75, -62, -38, -5, 28, 54, 70, 24, 4]
        return Pose(x=49 + frame // 3, lean=min(frame, 5), crouch=-2 if frame > 3 else 0, front_arm=angles[frame], back_arm=40, front_leg=5 + frame // 2, back_leg=-5, weapon_angle=angles[frame], cape=frame // 2)
    if skill == "sword_up_diagonal_slash":
        angles = [45, 35, 18, -4, -28, -48, -67, -22, 2]
        return Pose(x=49 + frame // 4, lean=frame // 2, crouch=-3 if 2 <= frame <= 5 else 0, front_arm=angles[frame], back_arm=25, front_leg=7, back_leg=-6, weapon_angle=angles[frame], cape=frame // 3)
    if skill == "sword_wave":
        angles = [-55, -42, -25, 0, 18, 34, 48, 17, 0]
        return Pose(x=48, lean=min(frame, 4), crouch=-2, front_arm=angles[frame], back_arm=35, front_leg=6, back_leg=-7, weapon_angle=angles[frame], cape=min(frame, 5))
    if skill == "axe_swing":
        angles = [-105, -92, -70, -30, 10, 48, 62, 32, -5]
        return Pose(x=47, lean=frame // 2, crouch=-5 if frame >= 4 else 0, front_arm=angles[frame], back_arm=angles[frame] + 12, front_leg=8, back_leg=-8, weapon_angle=angles[frame], cape=frame // 2)
    if skill == "axe_body_charge":
        leans = [2, 5, 9, 11, 10, 11, 9, 5, 2]
        if frame >= 7:
            return Pose(x=49, lean=leans[frame], crouch=-4 if frame == 7 else -1, front_arm=6 if frame == 7 else 14, back_arm=12, front_leg=7, back_leg=-5, weapon_angle=4 if frame == 7 else 12, cape=5 if frame == 7 else 2)
        return Pose(x=49 + (frame % 2), lean=leans[frame], crouch=-7, front_arm=2, back_arm=8, front_leg=10 - frame % 3, back_leg=-7 + frame % 3, weapon_angle=-2, cape=10 if frame >= 2 else 4)
    if skill == "axe_spin_charge":
        angles = [-80, -35, 15, 60, 125, 170, 220, 280, 335]
        return Pose(x=51 + frame // 3, lean=0, crouch=-5, front_arm=angles[frame], back_arm=angles[frame] + 15, front_leg=6 if frame % 2 else -4, back_leg=-6 if frame % 2 else 5, weapon_angle=angles[frame], cape=(frame % 3) * 3)
    if skill == "bow_air_arrow_shot":
        ys = [0, -3, -9, -15, -18, -16, -10, -4, 0]
        return Pose(x=48 + frame // 4, y=ys[frame], lean=-2, crouch=0, front_arm=-28, back_arm=188 if frame < 5 else 165, front_leg=7 if frame < 4 else -2, back_leg=-5 if frame < 4 else 5, weapon_angle=28, cape=7, airborne=frame not in (0, 8))
    if skill == "bow_rapid_shot":
        pulls = [158, 181, 166, 187, 171, 193, 174, 169, 163]
        return Pose(x=47 + (1 if frame in (3, 5) else 0), lean=2 + frame % 2, crouch=-2 - (1 if frame in (3, 5) else 0), front_arm=-2 + frame % 3, back_arm=pulls[frame], front_leg=6 + frame % 2, back_leg=-6, weapon_angle=frame % 2, cape=1 + frame % 4)
    if skill == "bow_low_charge_shot":
        pulls = [160, 168, 176, 184, 192, 195, 165, 171, 168]
        if frame >= 7:
            return Pose(x=47, lean=4 if frame == 7 else 1, crouch=-5 if frame == 7 else -1, front_arm=1 if frame == 7 else 3, back_arm=174 if frame == 7 else 164, front_leg=8 if frame == 7 else 4, back_leg=-7 if frame == 7 else -3, weapon_angle=1 if frame == 7 else 3, cape=3 if frame == 7 else 1)
        if frame == 6:
            return Pose(x=47, lean=10, crouch=-7, front_arm=-3, back_arm=165, front_leg=11, back_leg=-7, weapon_angle=-2, cape=8)
        return Pose(x=46, lean=7, crouch=-9, front_arm=0, back_arm=pulls[frame], front_leg=10, back_leg=-8, weapon_angle=0, cape=5)
    if skill == "lance_charge_thrust":
        leans = [3, 5, 9, 11, 12, 11, 10, 6, 2]
        if frame >= 7:
            return Pose(x=49, lean=leans[frame], crouch=-3 if frame == 7 else 0, front_arm=4 if frame == 7 else 9, back_arm=7, front_leg=8, back_leg=-6, weapon_angle=3 if frame == 7 else 8, cape=6 if frame == 7 else 2)
        return Pose(x=49 + (frame % 2), lean=leans[frame], crouch=-6, front_arm=0, back_arm=5, front_leg=12 - frame % 4, back_leg=-9 + frame % 4, weapon_angle=0, cape=10)
    if skill == "lance_thrust_combo":
        angles = [8, -5, 7, -12, 9, -3, 5, 2, 0]
        reach = [0, 7, 1, 9, 2, 10, 2, 0, 0]
        return Pose(x=46 + reach[frame], lean=reach[frame], crouch=-3, front_arm=angles[frame], back_arm=angles[frame] + 5, front_leg=8, back_leg=-7, weapon_angle=angles[frame], cape=reach[frame] // 2)
    if skill == "lance_finisher_thrust":
        xs = [43, 43, 45, 50, 60, 70, 73, 69, 64]
        if frame == 1:
            return Pose(x=44, lean=3, crouch=-2, front_arm=-5, back_arm=8, front_leg=10, back_leg=-8, weapon_angle=-4, cape=5)
        if frame >= 7:
            return Pose(x=61 if frame == 7 else 54, lean=7 if frame == 7 else 2, crouch=-4 if frame == 7 else -1, front_arm=3 if frame == 7 else 10, back_arm=6, front_leg=9, back_leg=-7, weapon_angle=2 if frame == 7 else 9, cape=7 if frame == 7 else 3)
        return Pose(x=xs[frame], lean=min(13, frame * 2), crouch=-8, front_arm=0, back_arm=3, front_leg=12, back_leg=-10, weapon_angle=0, cape=12 if frame >= 3 else 4)
    if skill == "shield_charge":
        leans = [4, 8, 11, 12, 12, 11, 10, 6, 1]
        if frame >= 7:
            return Pose(x=49, lean=leans[frame], crouch=-3 if frame == 7 else 0, front_arm=4 if frame == 7 else 8, back_arm=10, front_leg=8, back_leg=-6, shield_angle=3 if frame == 7 else 0, cape=5 if frame == 7 else 1)
        if frame == 6:
            return Pose(x=49, lean=10, crouch=-6, front_arm=-2, back_arm=10, front_leg=5, back_leg=-4, shield_angle=-2, cape=7)
        return Pose(x=49 + (frame % 2), lean=leans[frame], crouch=-7, front_arm=0, back_arm=12, front_leg=11 - frame % 4, back_leg=-8 + frame % 4, shield_angle=0, cape=9)
    if skill == "shield_slam":
        angles = [-70, -82, -95, -100, -45, 10, 38, 18, 2]
        return Pose(x=49, lean=0, crouch=-10 if frame >= 4 else 0, front_arm=angles[frame], back_arm=angles[frame] + 8, front_leg=7, back_leg=-7, shield_angle=angles[frame], cape=3)
    if skill == "shield_diagonal_knockback":
        angles = [22, 15, 5, -15, -32, -48, -62, -25, 0]
        return Pose(x=47 + frame // 3, lean=min(9, frame), crouch=-4, front_arm=angles[frame], back_arm=10, front_leg=9, back_leg=-7, shield_angle=angles[frame], cape=frame // 2)
    raise ValueError(skill)


def build_skill(weapon: str, skill: str) -> dict[str, object]:
    frame_dir = ASSET_ROOT / weapon / "Sprites/hys_FinalSkills" / skill
    frame_dir.mkdir(parents=True, exist_ok=True)
    frames: list[Image.Image] = []
    hashes: list[str] = []
    for index in range(FRAME_COUNT):
        frame = Image.new("RGBA", CANVAS, (0, 0, 0, 0))
        draw_character(frame, weapon, pose_for(skill, index), index, skill)
        path = frame_dir / f"hys_Enemy_{weapon}_{skill}_{index:02d}.png"
        frame.save(path)
        frames.append(frame)
        hashes.append(hashlib.sha256(frame.tobytes()).hexdigest())

    gif_frames = [frame.resize((CANVAS[0] * SCALE, CANVAS[1] * SCALE), Image.Resampling.NEAREST) for frame in frames]
    GIF_ROOT.mkdir(parents=True, exist_ok=True)
    gif_path = GIF_ROOT / f"hys_Final_Enemy_{weapon}_{skill}.gif"
    frame_ms = max(20, round(SKILL_DURATIONS_MS[skill] / FRAME_COUNT / 10) * 10)
    gif_frames[0].save(
        gif_path,
        save_all=True,
        append_images=gif_frames[1:],
        duration=frame_ms,
        loop=0,
        disposal=2,
        transparency=0,
        optimize=False,
    )
    return {
        "weapon": weapon,
        "skill": skill,
        "frames": FRAME_COUNT,
        "unique_frames": len(set(hashes)),
        "canvas": list(CANVAS),
        "ground_y": GROUND_Y,
        "duration_ms": SKILL_DURATIONS_MS[skill],
        "gif_frame_ms": frame_ms,
        "gif": str(gif_path),
    }


def build_contact_sheet(results: list[dict[str, object]]) -> None:
    thumb_scale = 2
    row_height = CANVAS[1] * thumb_scale
    label_width = 360
    reference_names = {"Sword": "Sword_monster.png", "Axe": "Axe_monster.png", "Bow": "Bow_monster.png", "Lance": "Lance_monster.png", "Shield": "Shiled_monster.png"}
    sheet = Image.new("RGB", (label_width + CANVAS[0] * thumb_scale * FRAME_COUNT, row_height * len(results)), "#1c2029")
    draw = ImageDraw.Draw(sheet)
    for row, result in enumerate(results):
        weapon = str(result["weapon"])
        skill = str(result["skill"])
        draw.text((8, row * row_height + 8), f"{weapon} / {skill}", fill="white")
        draw.text((205, row * row_height + 8), "IDENTITY REFERENCE ONLY", fill="#f2c45b")
        reference = Image.open(ROOT / "Assets/06Sprites" / reference_names[weapon]).convert("RGBA")
        reference = reference.resize((128, 128), Image.Resampling.NEAREST)
        reference_bg = Image.new("RGBA", reference.size, "#1c2029")
        reference_bg.alpha_composite(reference)
        sheet.paste(reference_bg.convert("RGB"), (205, row * row_height + 36))
        frame_dir = ASSET_ROOT / weapon / "Sprites/hys_FinalSkills" / skill
        for index in range(FRAME_COUNT):
            frame = Image.open(frame_dir / f"hys_Enemy_{weapon}_{skill}_{index:02d}.png").convert("RGBA")
            bg = Image.new("RGBA", CANVAS, "#1c2029")
            bg.alpha_composite(frame)
            bg = bg.resize((CANVAS[0] * thumb_scale, row_height), Image.Resampling.NEAREST)
            sheet.paste(bg.convert("RGB"), (label_width + index * CANVAS[0] * thumb_scale, row * row_height))
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    sheet.save(REPORT_ROOT / "hys_Final_15_AllFrames_ContactSheet.png")


def build_animated_preview(results: list[dict[str, object]]) -> None:
    """15개 GIF를 한 화면에서 동시에 재생해 육안 검증할 수 있는 미리보기를 만듭니다."""
    columns = 3
    rows = 5
    preview_scale = 2
    cell_width = CANVAS[0] * preview_scale
    cell_height = CANVAS[1] * preview_scale + 24
    preview_frames: list[Image.Image] = []
    for frame_index in range(FRAME_COUNT):
        preview = Image.new("RGB", (cell_width * columns, cell_height * rows), "#1c2029")
        preview_draw = ImageDraw.Draw(preview)
        for item_index, result in enumerate(results):
            weapon = str(result["weapon"])
            skill = str(result["skill"])
            source = ASSET_ROOT / weapon / "Sprites/hys_FinalSkills" / skill / f"hys_Enemy_{weapon}_{skill}_{frame_index:02d}.png"
            sprite = Image.open(source).convert("RGBA").resize((CANVAS[0] * preview_scale, CANVAS[1] * preview_scale), Image.Resampling.NEAREST)
            cell_x = (item_index % columns) * cell_width
            cell_y = (item_index // columns) * cell_height
            preview_draw.text((cell_x + 6, cell_y + 5), f"{weapon} / {skill}", fill="white")
            layer = Image.new("RGBA", sprite.size, "#1c2029")
            layer.alpha_composite(sprite)
            preview.paste(layer.convert("RGB"), (cell_x, cell_y + 24))
        preview_frames.append(preview)
    preview_frames[0].save(
        REPORT_ROOT / "hys_Final_15_AnimatedPreview.gif",
        save_all=True,
        append_images=preview_frames[1:],
        duration=90,
        loop=0,
        optimize=False,
    )


def main() -> None:
    # 매 실행마다 15개 전체를 다시 출력하여 부분 갱신된 GIF가 남지 않도록 합니다.
    if GIF_ROOT.exists():
        shutil.rmtree(GIF_ROOT)
    results: list[dict[str, object]] = []
    for weapon, skills in SKILLS.items():
        for skill in skills:
            results.append(build_skill(weapon, skill))
    build_contact_sheet(results)
    build_animated_preview(results)
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    (REPORT_ROOT / "hys_Final_15_ExportReport.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Final Version 15 GIFs exported: {GIF_ROOT}")


if __name__ == "__main__":
    main()
