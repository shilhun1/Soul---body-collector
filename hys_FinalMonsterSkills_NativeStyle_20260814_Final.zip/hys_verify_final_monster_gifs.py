from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

from PIL import Image, ImageChops


# 15개 최종 GIF를 매 검증 회차마다 처음부터 끝까지 모두 디코딩해 품질 조건을 확인합니다.
ROOT = Path(__file__).resolve().parents[1]
GIF_ROOT = ROOT.parent / "hys_FinalVersion_15_GIFs"
REPORT_ROOT = ROOT / "hys_Reports/MonsterSkillFinal"
SPRITE_ROOT = ROOT / "Assets/05Anims/hys_Enemy_Anims"
REFERENCE_PATHS = {
    "Sword": "Assets/Pixel art Chess Knights pack/05_Queen/Red_Queen/R_Queen_idle00.png",
    "Axe": "Assets/05Anims/hys_Player_Anims/Axe/Sprites/hys_RedKing_PlayerMotions/hys_RedKing_Idle_02.png",
    "Bow": "Assets/05Anims/hys_Player_Anims/Bow/Sprites/hys_RedBishop_Bow_PlayerMotions/hys_RedBishop_Bow_Idle_00.png",
    "Lance": "Assets/05Anims/hys_Player_Anims/Lance/Sprites/hys_RedBishop_PlayerMotions/hys_RedBishop_Idle_00.png",
    "Shield": "Assets/05Anims/hys_Player_Anims/Shield/Sprites/hys_RedRook_Idle_00.png",
}
NATIVE_SOURCE_ROOTS = {
    "Sword": ROOT / "Assets/Pixel art Chess Knights pack/05_Queen/Red_Queen",
    "Axe": ROOT / "Assets/05Anims/hys_Player_Anims/Axe/Sprites/hys_RedKing_PlayerMotions",
    "Bow": ROOT / "Assets/05Anims/hys_Player_Anims/Bow/Sprites/hys_RedBishop_Bow_PlayerMotions",
    "Lance": ROOT / "Assets/05Anims/hys_Player_Anims/Lance/Sprites/hys_RedBishop_PlayerMotions",
    "Shield": ROOT / "Assets/05Anims/hys_Player_Anims/Shield/Sprites",
}
EXPECTED = {
    "Sword": ["sword_diagonal_slash", "sword_up_diagonal_slash", "sword_wave"],
    "Axe": ["axe_swing", "axe_body_charge", "axe_spin_charge"],
    "Bow": ["bow_air_arrow_shot", "bow_rapid_shot", "bow_low_charge_shot"],
    "Lance": ["lance_charge_thrust", "lance_thrust_combo", "lance_finisher_thrust"],
    "Shield": ["shield_charge", "shield_slam", "shield_diagonal_knockback"],
}
EXPECTED_SIZE = (640, 448)
EXPECTED_FRAMES = 9
EXPECTED_DURATION = 90


def decode(path: Path) -> tuple[list[Image.Image], list[int]]:
    image = Image.open(path)
    frames: list[Image.Image] = []
    durations: list[int] = []
    index = 0
    while True:
        try:
            image.seek(index)
        except EOFError:
            break
        frames.append(image.convert("RGBA"))
        durations.append(int(image.info.get("duration", 0)))
        index += 1
    return frames, durations


def center_of_alpha(frame: Image.Image) -> tuple[float, float]:
    box = frame.getchannel("A").getbbox()
    if box is None:
        return 0.0, 0.0
    return (box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0


def changed_ratio(left: Image.Image, right: Image.Image) -> float:
    diff = ImageChops.difference(left, right).convert("RGB")
    changed = sum(1 for pixel in diff.get_flattened_data() if pixel != (0, 0, 0))
    return changed / float(left.width * left.height)


def verify_one(path: Path) -> dict[str, object]:
    frames, durations = decode(path)
    hashes = [hashlib.sha256(frame.tobytes()).hexdigest() for frame in frames]
    boxes = [frame.getchannel("A").getbbox() for frame in frames]
    changes = [changed_ratio(frames[index], frames[index + 1]) for index in range(len(frames) - 1)]
    start_center = center_of_alpha(frames[0])
    end_center = center_of_alpha(frames[-1])
    # 무기 각도가 달라져도 몸통/망토가 시작 위치로 돌아왔는지는 실루엣 왼쪽 기준선으로 확인합니다.
    recovery_distance = abs(boxes[0][0] - boxes[-1][0]) if boxes[0] and boxes[-1] else 9999.0
    no_edge_clip = all(
        box is not None
        and box[0] > 0
        and box[1] > 0
        and box[2] < EXPECTED_SIZE[0]
        and box[3] < EXPECTED_SIZE[1]
        for box in boxes
    )
    checks = {
        "frame_count_9": len(frames) == EXPECTED_FRAMES,
        "all_frames_unique": len(set(hashes)) == EXPECTED_FRAMES,
        "size_consistent": all(frame.size == EXPECTED_SIZE for frame in frames),
        "duration_consistent": durations == [EXPECTED_DURATION] * EXPECTED_FRAMES,
        "transparent_margin_no_clip": no_edge_clip,
        "continuous_motion": bool(changes) and min(changes) > 0.0002 and max(changes) < 0.30,
        "recovery_near_start": recovery_distance <= 80.0,
    }
    return {
        "file": path.name,
        "frames": len(frames),
        "durations_ms": durations,
        "unique_frames": len(set(hashes)),
        "alpha_boxes": boxes,
        "change_ratios": [round(value, 6) for value in changes],
        "recovery_distance_scaled_pixels": round(recovery_distance, 2),
        "checks": checks,
        "passed": all(checks.values()),
        "hashes": hashes,
    }


def reference_palette(weapon: str, count: int = 64) -> set[tuple[int, int, int]]:
    """실제 사용 가능한 모든 네이티브 모션과 1px 효과 색상을 반환합니다."""
    colors: set[tuple[int, int, int]] = set()
    for path in NATIVE_SOURCE_ROOTS[weapon].glob("*.png"):
        source = Image.open(path).convert("RGBA")
        colors.update((r, g, b) for r, g, b, a in source.get_flattened_data() if a > 16)
    colors.update({(74, 0, 17), (223, 18, 37), (255, 119, 48), (255, 198, 168), (242, 242, 242)})
    return colors


def verify_unity_skill(weapon: str, skill: str) -> dict[str, object]:
    """9개 PNG의 GUID와 AnimationClip 참조 순서를 실제 파일에서 대조합니다."""
    frame_dir = SPRITE_ROOT / weapon / "Sprites/hys_FinalSkills" / skill
    frame_paths = sorted(frame_dir.glob(f"hys_Enemy_{weapon}_{skill}_*.png"))
    meta_paths = [Path(f"{path}.meta") for path in frame_paths]
    clip_path = SPRITE_ROOT / weapon / "Clips" / f"hys_Enemy_{weapon}_{skill}.anim"
    guids: list[str] = []
    import_settings_valid = True
    frame_sizes_valid = True
    transparent_margin_valid = True
    palette_valid = True
    allowed_colors = reference_palette(weapon)

    for frame_path, meta_path in zip(frame_paths, meta_paths):
        frame = Image.open(frame_path).convert("RGBA")
        box = frame.getchannel("A").getbbox()
        frame_sizes_valid &= frame.size == (160, 112)
        transparent_margin_valid &= bool(
            box and box[0] > 0 and box[1] > 0 and box[2] < frame.width and box[3] < frame.height
        )
        used_colors = {(r, g, b) for r, g, b, a in frame.get_flattened_data() if a > 16}
        palette_valid &= used_colors.issubset(allowed_colors)

        if not meta_path.exists():
            continue
        meta = meta_path.read_text(encoding="utf-8")
        match = re.search(r"^guid: ([0-9a-f]{32})$", meta, re.MULTILINE)
        if match:
            guids.append(match.group(1))
        import_settings_valid &= all(
            setting in meta
            for setting in (
                "enableMipMap: 0",
                "filterMode: 0",
                "spriteMode: 1",
                "spritePixelsToUnits: 16",
                "alphaIsTransparency: 1",
                "textureType: 8",
            )
        )

    clip_guids: list[str] = []
    clip_text = clip_path.read_text(encoding="utf-8") if clip_path.exists() else ""
    if clip_text:
        clip_guids = re.findall(
            r"value: \{fileID: 21300000, guid: ([0-9a-f]{32}), type: 3\}", clip_text
        )
    checks = {
        "nine_png_frames": len(frame_paths) == EXPECTED_FRAMES,
        "nine_meta_files": len(meta_paths) == EXPECTED_FRAMES and all(path.exists() for path in meta_paths),
        "unity_import_settings": import_settings_valid,
        "frame_size_160x112": frame_sizes_valid,
        "transparent_margin_no_clip": transparent_margin_valid,
        "colors_from_actual_reference": palette_valid,
        "clip_exists": clip_path.exists(),
        "clip_guid_order_matches_frames": len(guids) == EXPECTED_FRAMES and clip_guids == guids,
        "clip_sample_rate_12": "m_SampleRate: 12" in clip_text,
    }
    return {
        "weapon": weapon,
        "skill": skill,
        "frame_count": len(frame_paths),
        "clip_guid_count": len(clip_guids),
        "checks": checks,
        "passed": all(checks.values()),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pass-number", type=int, required=True)
    parser.add_argument("--stage", required=True)
    args = parser.parse_args()

    expected_paths = [
        GIF_ROOT / f"hys_Final_Enemy_{weapon}_{skill}.gif"
        for weapon, skills in EXPECTED.items()
        for skill in skills
    ]
    results = [verify_one(path) for path in expected_paths if path.exists()]
    all_hashes: dict[str, list[str]] = {}
    for result in results:
        for frame_index, value in enumerate(result["hashes"]):
            all_hashes.setdefault(value, []).append(f"{result['file']}#{frame_index}")
    duplicates = [locations for locations in all_hashes.values() if len(locations) > 1]
    unity_results = [
        verify_unity_skill(weapon, skill)
        for weapon, skills in EXPECTED.items()
        for skill in skills
    ]

    summary_checks = {
        "all_15_exist": len(results) == 15 and all(path.exists() for path in expected_paths),
        "all_135_frames_are_unique": not duplicates,
        "all_individual_checks_pass": len(results) == 15 and all(bool(result["passed"]) for result in results),
        "all_135_unity_frames_exist": sum(int(result["frame_count"]) for result in unity_results) == 135,
        "all_15_clip_guid_sequences_match": all(
            bool(result["checks"]["clip_guid_order_matches_frames"]) for result in unity_results
        ),
        "all_unity_asset_checks_pass": all(bool(result["passed"]) for result in unity_results),
        "all_actual_reference_files_exist": all((ROOT / path).exists() for path in REFERENCE_PATHS.values()),
        "skill_specific_motion_names": len({path.stem for path in expected_paths}) == 15,
    }
    report = {
        "pass_number": args.pass_number,
        "stage": args.stage,
        "summary_checks": summary_checks,
        "cross_skill_duplicate_frames": duplicates,
        "weapon_invariants": {
            "Sword": "붉은 손잡이 7px / 금색 가드 7px / 은색 직선 칼날 29px 고정",
            "Axe": "손잡이·양날 도끼 머리 치수와 적색/주황 팔레트 고정",
            "Bow": "활 높이 36px와 붉은 프레임·은색 시위 고정",
            "Lance": "자루 54px와 은색 창끝 8px 고정",
            "Shield": "34x46 원본형 방패와 중앙 금색 보강대 고정",
        },
        "actual_reference_paths": REFERENCE_PATHS,
        "unity_asset_results": unity_results,
        "results": [{key: value for key, value in result.items() if key != "hashes"} for result in results],
        "passed": all(summary_checks.values()),
    }
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    report_path = REPORT_ROOT / f"hys_FinalValidation_Pass{args.pass_number}_{args.stage}.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"report": str(report_path), "passed": report["passed"], "summary": summary_checks}, ensure_ascii=False))
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
